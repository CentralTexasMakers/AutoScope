This is a library for the Adafruit NEC Remote Control

  Designed specifically to work with the Adafruit NEC Remote Control
	----> http://www.adafruit.com/products/389
  and IR Receiver Sensor
	----> http://www.adafruit.com/products/157

These devices use IR to communicate, 1 pin is required to  
interface
Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Written by Limor Fried/Ladyada for Adafruit Industries.  
BSD license, all text above must be included in any redistribution

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder Adafruit_NECremote. Check that the Adafruit_NECremote folder contains Adafruit_NECremote.cpp and Adafruit_NECremote.h

Place the Adafruit_NECremote library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.